package com.jh.test;

public class ListviewContactItem {
	 
	String name;
	String phone;
	public void SetName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
		
	}
public void SetPhone(String string) 
{
		// TODO Auto-generated method stub
	this.phone=string;	
}

 public String getName()
 {
	return name;
 }
 public String getPhone()
 {
	return phone;
 }

}
