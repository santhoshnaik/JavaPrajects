/** Automatically generated file. DO NOT MODIFY */
package com.jh.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}