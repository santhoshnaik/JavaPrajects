package com.justhire.driver;

import com.justhire.mobile.R;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class DashActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dash);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_dash, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.title:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void customerProfile(View dashView) {
		Intent intent = new Intent(this,
				com.justhire.mobile.login.ProfileActivity.class);
		setParams(intent);
		startActivity(intent);

	}

	public void bookDriver(View dashView) {
		ProgressDialog dialog = ProgressDialog.show(this, "",  
				 "Loading Booking screen with Location Details. Please wait...", true);
		Intent intent = new Intent(this,
				com.justhire.mobile.booking.BookDriverActivity.class);
		setParams(intent);
		startActivity(intent);
		if(dialog!=null)
		{
			dialog.dismiss();
		}

	}

	public void bookTaxi(View dashView) {
		Intent intent = new Intent(this,
				com.justhire.mobile.booking.BookTaxiActivity.class);
		setParams(intent);
		startActivity(intent);
	}

	public void bookStatus(View dashView) {
		Intent intent = new Intent(this,
				com.justhire.mobile.booking.BookStatusActivity.class);
        setParams(intent);		
		startActivity(intent);

	}
	
	private void setParams(Intent intent)
	{
		intent.putExtra("un", this.getIntent().getExtras().getString("un"));
		intent.putExtra("pd", this.getIntent().getExtras().getString("pd"));
		intent.putExtra("cid", this.getIntent().getExtras().getString("cid"));
		intent.putExtra("mNo", this.getIntent().getExtras().getString("mNo"));
		intent.putExtra("area", this.getIntent().getExtras().getString("area"));
		intent.putExtra("name", this.getIntent().getExtras().getString("name"));
		
	}

	public void onClick(View loginView) {

	}
	
	public void viewDash(View bookView) {
		//onBackPressed();
	}
	
	public void signout(View dashView) {
		Intent intent = new Intent(this,
				com.justhire.mobile.login.LoginAction.class);
		intent.removeExtra("un");
		intent.removeExtra("pd");
		intent.removeExtra("cid");
		intent.removeExtra("mNo");
		intent.removeExtra("area");
		intent.removeExtra("name");
		startActivity(intent);

	}
	
 
	
}
